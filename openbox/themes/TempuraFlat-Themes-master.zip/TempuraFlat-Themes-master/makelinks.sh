#!/bin/bash

usage() {
	echo "usage:

	$(basename $0) \"dir\"

	where dir is the directory you want to install to
	(defaults to \"\$HOME/.themes\" if omitted).
"
	exit 1
}

if [[ "x$1" != "x" ]]
then
	[ -d "$1" ] || usage
	dir="$1"
else
	dir="$HOME/.themes"
fi

names="$PWD/TempuraFlat*"
ln -s $names "$dir/"