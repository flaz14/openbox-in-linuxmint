## TempuraFlat GTK2, GTK3, Openbox and tint2 Themes

![Screenshot](http://iki.fi/dt/stuff/TF/TempuraFlat-lx.png)  
[All features screenshot](http://iki.fi/dt/stuff/TF/megascrot.png)

Includes a tint2 config file, utilizing the Exec plugin - see e.g.
[ohnonot/media-player-info](https://github.com/ohnonot/media-player-info)
for a suitable script.

Openbox theme variations ([screenshot](http://iki.fi/dt/stuff/TF/ob.png)):  
Some are more suitable for undecorated windows - the light/dark border
makes focused/unfocused clearly recognizable.

## Dependencies

The gtk murrine engine, and the mist engine for nice looking checkboxes for gtk2.

## Installation

Just clone it to wherever you like, then run `./makelinks.sh "directory"`.  
If you omit "directory", it will default to `~/.themes`.  
If you are using e.g. lxpanel, you can try the included 30px panel backgrounds.

## Helpful snippets

If you store tint2rcs with your gtk themes, you can put something like this in
your `~/.*profile`...

    export GTK2_RC_FILES="$HOME/.gtkrc-2.0"
    export GTK2_CURRENT_THEME="$(cut -d\" -f2 <<<"$(grep gtk-theme-name $GTK2_RC_FILES)")"

...and something like this in your `~/.xinitrc` or `~/.config/openbox/autostart`

    tint2rc="$HOME/.themes/$GTK2_CURRENT_THEME/tint2/tint2rc"
    if [ -f "$tint2rc" ]
    then
      tint2 -c "$tint2rc" &
    else
      tint2 &
    fi
    unset tint2rc
